<nav class="px-2 py-2">
    <h2 class="font-bold py-3">Browse by</h2>
    <ul>
        <li><a class="px-5" href="{{route("io.index")}}">შესანახი ობიექტები</a></li>
        <li><a class="px-5" href="#">Link</a></li>
        <li><a class="px-5" href="#">Link</a></li>
        <li><a class="px-5" href="#">Link</a></li>
    </ul>
    <h2  class="font-bold py-3">Popular this week</h2>
    <ul>
        <li><a class="px-5" href="#">Link</a></li>
        <li><a class="px-5" href="#">Link</a></li>
        <li><a class="px-5" href="#">Link</a></li>
        <li><a class="px-5" href="#">Link</a></li>
    </ul>
</nav>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link href="<?php echo e(asset('favicon.ico')); ?>" rel="icon">
    <title>აჭარის არქივი</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/viewer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/stylesheet.css')); ?> ">

    <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="hold-transition layout-top-nav">
    <div class="container-fluid">
        <?php $__env->startSection("content"); ?>
        <?php echo $__env->yieldSection(); ?>
    </div>
    <script src="<?php echo e(asset('js/viewer.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/layouts/viewer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('body'); ?>


    <?php if (isset($component)) { $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorAlert::class, []); ?>
<?php $component->withName('error-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c)): ?>
<?php $component = $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c; ?>
<?php unset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>

    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4"> <?php echo e($type->name); ?> </h1>
        </div>
    </div>


    <form action="<?php echo e(route("data.update",['id'=>$id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="table" value="<?php echo e($type->table); ?>">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group mb-3">
            <label for="<?php echo e($index); ?>" class="p-2"><?php echo e($translation[$index]); ?></label>
            <input type="text" name="<?php echo e($index); ?>" class="form-control" id="<?php echo e($index); ?>" value="<?php echo e($value); ?>" placeholder="<?php echo e($translation[$index]); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit" class="btn btn-success">
            <span class="material-icons md-light">save</span>
            შენახვა
        </button>
        <a type="submit" href="<?php echo e(route("io.show", ['id'=> $id])); ?>" class="btn btn-danger">
            <span class="material-icons md-light">arrow_back</span>
            დაბრუნება
        </a>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/tables/show.blade.php ENDPATH**/ ?>
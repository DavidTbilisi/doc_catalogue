<?php $__env->startSection('body'); ?>

    <div class="container">
        <?php if (isset($component)) { $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorAlert::class, []); ?>
<?php $component->withName('error-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c)): ?>
<?php $component = $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c; ?>
<?php unset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c); ?>
<?php endif; ?>
    </div>

    <h1 class="mt-4"><?php echo e($io->reference); ?> (<?php echo e($io->type->name); ?>)</h1>




        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <h2 class="mb-4 mt-4"><?php echo e($perms['group']->alias); ?> </h2>

          <form action="<?php echo e(route("io_perms.update", ['group_id'=>$perms['group']->id, 'io_id'=>$io->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <div class="row">

        <?php $__currentLoopData = $perms["all"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array( $permission->const_name, $permissions[$index]['permitted'] )): ?>

                <div class="col-3">
                    <div class="form-check form-switch">
                        <input class="form-check-input" name="<?php echo e($permission->power); ?>" type="checkbox" role="switch" id="<?php echo e($permission->const_name.$perms['group']->alias); ?>" checked>
                        <label class="form-check-label" for="<?php echo e($permission->const_name.$perms['group']->alias); ?>"><?php echo e($permission->name); ?></label>
                    </div>
                </div>

            <?php else: ?>

                <div class="col-3">
                    <div class="form-check form-switch">
                        <input class="form-check-input" name="<?php echo e($permission->power); ?>" type="checkbox" role="switch" id="<?php echo e($permission->const_name.$perms['group']->alias); ?>">
                        <label class="form-check-label" for="<?php echo e($permission->const_name.$perms['group']->alias); ?>"><?php echo e($permission->name); ?></label>
                    </div>
                </div>

            <?php endif; ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3">
                <input type="submit" value="შენახვა" class="btn btn-success">
            </div>
        </div>

      </form>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/io/io_permissions.blade.php ENDPATH**/ ?>
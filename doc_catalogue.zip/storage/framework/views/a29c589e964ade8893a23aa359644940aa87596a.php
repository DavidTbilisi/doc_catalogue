<div>
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
    <?php if(Session::has("type")): ?>
        <div class="alert alert-<?php echo e(Session::get("type")); ?>">
            <?php echo e(Session::get("message")); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/components/alert.blade.php ENDPATH**/ ?>
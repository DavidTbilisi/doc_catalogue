<?php $__env->startSection('body'); ?>
    <div class="container">

        <?php if (isset($component)) { $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorAlert::class, []); ?>
<?php $component->withName('error-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c)): ?>
<?php $component = $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c; ?>
<?php unset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c); ?>
<?php endif; ?>




        <div class="mt-3">
            <p class="h1"> საინფორმაციო ობიექტის დამატება </p>

            <form action="<?php echo e(route("io.update",['id'=>$io->id])); ?>" method="post" id="io" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="io_type_id" value="<?php echo e($io->io_type_id); ?>">

            <div class="mb-3">
                <label for="prefix" class="form-label">პრეფიქსი</label>
                <input type="text" class="form-control" name="prefix" id="prefix" placeholder="პრეფიქსი" value="<?php echo e($io->prefix); ?>">
            </div>

            <div class="mb-3">
                <label for="identifier" class="form-label">იდენტიფიკატორი</label>
                <input type="text" class="form-control" name="identifier" id="identifier" placeholder="იდენტიფიკატორი" value="<?php echo e($io->identifier); ?>">
            </div>

            <div class="mb-3">
                <label for="suffix" class="form-label">სუფიქსი</label>
                <input type="text" class="form-control" name="suffix" id="suffix" placeholder="სუფიქსი" value="<?php echo e($io->suffix); ?>">
            </div>

            <div class="mb-3">
                <label for="type" class="form-label">ტიპი</label>
                <select class="form-control" name="io_type_id" id="type" onchange="getFields(event)">
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($io->type->table == $type->table): ?>
                            <option selected value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="docs row">
                <div class="col">
                    <label for="files">ფაილების ატვირთვა:</label>
                    <input type="file" class="form-control" id="files" name="files[]" multiple>
                </div>
                <div class="col">
                    <a class="btn btn-primary mt-4 w-100" target="_blank" href="<?php echo e(route("elfinder.ckeditor")."#elf_".$startPath); ?>">ფაილების დათვალიერება</a>
                </div>
            </div>


            <div class="mb-3 mt-5 row">
                <div class="col">
                    <button class="btn btn-success w-100" >განახლება</button>
                </div>
                <div class="col">
                    <a class="btn btn-danger w-100" href="<?php echo e(route('io.index')); ?>">უკან</a>
                </div>
            </div>

            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/io/io_edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('body'); ?>

<div class="container">
    <?php if (isset($component)) { $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorAlert::class, []); ?>
<?php $component->withName('error-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c)): ?>
<?php $component = $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c; ?>
<?php unset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c); ?>
<?php endif; ?>
</div>

<table class="table mt-4">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">იდენტიფიკატორი</th>
        <th scope="col">რეფერენსი</th>
        <th scope="col">ტიპი</th>
        <th scope="col">მოქმედება</th>
    </tr>
    </thead>
    <tbody>

<?php $__currentLoopData = $iolist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $io): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e(++$loop->index); ?></th>
            <td class="identifier">
                <?php echo e($identifiers[$loop->index-1]); ?>

            </td>
            <td class="reference"><?php echo e($io->reference); ?></td>
            <td class="type"><?php echo e($io->type->name); ?></td>
            <td>

            <?php if ( Perms::hasPerm('viewObject') )  : ?>
                <?php echo csrf_field(); ?>


                <a href="<?php echo e(route("io.show", ["id"=>$io->id])); ?>" class="btn btn-success">
                    <span class="material-icons md-light">visibility</span>
                </a>
                <?php if ( Perms::hasPerm('editObject') )  : ?>
                <a href="<?php echo e(route("io.edit", ["id"=>$io->id])); ?>" class="btn btn-info">
                    <span class="material-icons md-light">edit</span>
                </a>
                <?php endif; ?>

                <?php if ( Perms::isGroup("admin") )  : ?>
                <a href="<?php echo e(route("io_perms.show", ["id"=>$io->id])); ?>" class="btn btn-primary">
                    <span class="material-icons md-light">rule</span>
                </a>
                <?php endif; ?>


                <?php if ( Perms::hasPerm('deleteObject') )  : ?>
                <form class="form-check-inline" action="<?php echo e(route("io.delete", ["id"=>$io->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-danger">
                        <span class="material-icons md-light">delete</span>
                    </button>
                </form>

                <?php endif; ?>
            <?php endif; ?>
            </td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php if (isset($component)) { $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AddButton::class, ['route' => ''.e(route('io.add')).'']); ?>
<?php $component->withName('add-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612)): ?>
<?php $component = $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612; ?>
<?php unset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612); ?>
<?php endif; ?>

<script>

    $(function () {
        $('#jstree_demo_div').jstree();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/io/io_list.blade.php ENDPATH**/ ?>
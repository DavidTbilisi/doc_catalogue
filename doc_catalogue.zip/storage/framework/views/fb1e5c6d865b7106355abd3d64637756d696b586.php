<?php $__env->startSection('body'); ?>
<div class="container pt-4">
    <p class="h1">Permissions List</p>
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"> <?php echo e($index + 1); ?> </th>
            <td>
                <a href="<?php echo e(route("permissions.index", ['id'=>$permission->id])); ?>">
                    <?php echo e($permission->name); ?>

                </a>
            </td>
            <td><?php echo e($permission->description); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/permissions/permission_list.blade.php ENDPATH**/ ?>
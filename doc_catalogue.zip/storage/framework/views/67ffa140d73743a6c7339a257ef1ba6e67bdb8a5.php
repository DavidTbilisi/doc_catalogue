<?php $__env->startSection('body'); ?>

<?php if($errors->any()): ?>
<div class="container mt-3">
<div class="alert alert-danger alert-dismissible fade show">
<?php echo e($errors->first()); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
</div>
<?php endif; ?>


    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e(++$loop->index); ?></th>
            <td><a href="<?php echo e(route("types.show",['id'=>$type->table])); ?>"><?php echo e($type->name); ?></a></td>
            <?php if ( Perms::isGroup("admin") )  : ?>
            <form action="<?php echo e(route("types.delete",['id'=>$type->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="table" value="<?php echo e($type->table); ?>">
                <td>
                    <button class="btn btn-danger" onclick="return confirm('Do you really want to delete?')">
                        <span class="material-icons md-light"> delete_outline </span>
                    </button>
                </td>
            </form>
            <?php else: ?>
            <td>
                <button class="btn btn-danger" disabled>
                    <span class="material-icons md-light"> delete_outline </span>
                </button>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


    <?php if (isset($component)) { $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AddButton::class, ['route' => ''.e(route('types.add')).'']); ?>
<?php $component->withName('add-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612)): ?>
<?php $component = $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612; ?>
<?php unset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/iotypes/type_list.blade.php ENDPATH**/ ?>
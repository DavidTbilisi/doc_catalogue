<?php $__env->startSection('body'); ?>

<div class="container">
    <?php if (isset($component)) { $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorAlert::class, []); ?>
<?php $component->withName('error-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c)): ?>
<?php $component = $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c; ?>
<?php unset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c); ?>
<?php endif; ?>
    <br>
    <div id="jstree_demo_div" class="mt-5">  </div>

    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4"> საინფორმაციო ობიექტი
            <?php if ( Perms::hasPerm('editObject') )  : ?>
            <a href="<?php echo e(route('io.edit', ['id'=>$io->id])); ?>" class="material-icons md-light">edit</a>
            <?php endif; ?>
        </h1>
      </div>
    </div>

    <ul class="list-group">
        <li class="list-group-item"> <b> ტიპი: </b> <span>  <?php echo e($io->type->name); ?> </span> </li>
        <li class="list-group-item"> <b> რეფერენსი: </b> <span> <?php echo e($io->reference); ?> </span> </li>
        <li class="list-group-item"> <b> სუფიქსი: </b> <span> <?php echo e($io->suffix); ?> </span> </li>
        <li class="list-group-item"> <b> იდენტიფიკატორი: </b> <span> <?php echo e($io->identifier); ?> </span> </li>
        <li class="list-group-item"> <b> პრეფიქსი: </b> <span> <?php echo e($io->prefix); ?> </span> </li>
    </ul>

  <ul class="list-group mt-5 mb-5">
    <li class="list-group-item active">
        <?php if ( Perms::hasPerm('editObject') )  : ?>
        <a id="go-to-data" class="link-light" href="<?php echo e(route("data.edit",["id"=>$io->data_id, "table"=>$table])); ?>" >
        <?php endif; ?>
            <span class="material-icons md-light"> source </span>
            მონაცემი
        </a>
    </li>

  <?php if($data): ?>
    <?php $__currentLoopData = (array)$data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if( !preg_match("/_at|_id|^id$/i", $key) ): ?>
        <li class="list-group-item"> <b> <?php echo e($translation[$key]??$key); ?>: </b> <span> <?php echo e($value); ?> </span> </li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

  </ul>

    <div class="row">
    <?php if ( Perms::hasPerm('deleteDocument') )  : ?>
    <?php if(count($io->documents)): ?>
    <div class="col">
        <form action="<?php echo e(route('io.cleardocs', ["id"=>$io->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger w-100"
                    onclick="return confirm('დარწმუნებული ხარ რომ გინდა დოკუმენტების წაშლა?')">
                    <span class="material-icons md-light"> description </span>
                    დოკუმენტების გასუფთავება
            </button>
        </form>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if ( Perms::hasPerm('deleteObject') )  : ?>
    <div class="col">
        <form action="<?php echo e(route('io.delete', ["id"=>$io->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger w-100"
                    onclick="return confirm('საინფორმაციო ობიექტის წაშლით იშლება ყველა მასზე მიბმული ობიექტი. დარწმუნებული ხარ?')">
                    <span class="material-icons md-light"> account_tree </span>
                    ობიექტის წაშლა
            </button>
        </form>
    </div>
    <?php endif; ?>
    <?php if ( Perms::hasPerm('viewDocument') )  : ?>
        <?php if(count($io->documents)): ?>
        <div class="col">

                <a href="<?php echo e(route('viewer', ['io_id'=>$io->id])); ?>" target="_blank" class="btn btn-success w-100">
                    <span class="material-icons md-light"> photo_library </span>
                    სურათების ნახვა
                </a>
        </div>
        <?php endif; ?>

        <?php endif; ?>

    </div>
    <?php if ( Perms::hasPerm('viewDocument') )  : ?>
    <div class="documents mt-3">
        <?php $__currentLoopData = $io->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(asset("/storage/".$doc->filepath)); ?>" target="_blank">
                <?php if(strpos($doc->mimetype, "image") == -1): ?>

                    <a target="_blank" href="<?php echo e(asset("/storage/".$doc->filepath)); ?>"><?php echo e($doc->mimetype); ?></a>
                <?php endif; ?>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>


    <br>


  <?php if (isset($component)) { $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AddButton::class, ['route' => ''.e(route('io.add',['io_parent_id'=> $io->id])).'']); ?>
<?php $component->withName('add-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612)): ?>
<?php $component = $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612; ?>
<?php unset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612); ?>
<?php endif; ?>

<script>

    $(function () {
        $('#jstree_demo_div').jstree({
            'core' : {
                'data' :
                    <?php
                        $json = json_encode($children,  JSON_PRETTY_PRINT );
                        echo $json;
                    ?>

            }
        });
        $("#jstree_demo_div").bind("select_node.jstree", function(e, data) {
            console.log(data.node.original)
            window.location.href = data.node.original.a_attr;
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/io/io_view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('body'); ?>
<div class="container pt-4">
    <?php if (isset($component)) { $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorAlert::class, []); ?>
<?php $component->withName('error-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c)): ?>
<?php $component = $__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c; ?>
<?php unset($__componentOriginalb5cdbe3a1bc3848636cb76bad87486f6477a292c); ?>
<?php endif; ?>


    <?php if(session()->has("message")): ?>
        <div class="alert alert-info">
            <?php echo e(session()->get("message")); ?>

        </div>
    <?php endif; ?>



    <p class="h1">Groups List</p>
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Members</th>
            <th scope="col">Permissions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"> <?php echo e($index + 1); ?> </th>
            <td>
                <?php if ( Perms::isGroup("admin") )  : ?>
                <a href="<?php echo e(route("groups.update", ['id'=>$group->id])); ?>">
                <?php echo e($group->alias); ?>

                </a>
                <?php else: ?>
                <p><?php echo e($group->alias); ?></p>
                <?php endif; ?>
            </td>
            <td><?php echo e($group->users->count()); ?></td>
            <td>
                <?php $__currentLoopData = $group->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="btn btn-info m-1"><?php echo e($perm->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php if ( Perms::isGroup('admin') )  : ?>
    <?php if (isset($component)) { $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AddButton::class, ['route' => ''.e(route('groups.add')).'']); ?>
<?php $component->withName('add-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612)): ?>
<?php $component = $__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612; ?>
<?php unset($__componentOriginal794883ece790e20da5a9ceb3005d2197595ae612); ?>
<?php endif; ?>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch1/Code/PHP/larauth/resources/views/admin/groups/group_list.blade.php ENDPATH**/ ?>
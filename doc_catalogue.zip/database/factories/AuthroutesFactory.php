<?php

namespace Database\Factories;

use App\Models\Authroutes;
use Illuminate\Database\Eloquent\Factories\Factory;

class AuthroutesFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Authroutes::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
